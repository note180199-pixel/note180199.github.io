export type UserRole = 'admin' | 'coach' | 'player';

export interface User {
  username: string;
  password: string;
  role: UserRole;
  name: string;
  phone?: string;
}

export interface Team {
  id: string;
  name: string;
  logo?: string;
  coaches: Coach[];
  managers: Manager[];
}

export interface Coach {
  id: string;
  name: string;
  phone: string;
}

export interface Manager {
  id: string;
  name: string;
  phone: string;
}

export type Position = 'GK' | 'CB' | 'LB' | 'RB' | 'CDM' | 'CM' | 'CAM' | 'LW' | 'RW' | 'ST';
export type AgeGroup = 'U10' | 'U12' | 'U14' | 'U16';
export type PreferredFoot = 'ซ้าย' | 'ขวา' | 'ทั้งสอง';
export type BloodType = 'A' | 'B' | 'AB' | 'O' | 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export interface PlayerSkill {
  name: string;
  score: number; // 1-10
}

export interface Player {
  id: string;
  // Basic Info
  profileImage?: string;
  playerId: string;
  jerseyNumber: number;
  firstName: string;
  lastName: string;
  birthDate: string;
  ageGroup: AgeGroup;
  height: number; // cm
  weight: number; // kg
  bloodType: BloodType;
  healthNotes?: string;

  // Contact Info
  parentName: string;
  parentPhone: string;
  playerPhone?: string;
  facebook?: string;

  // Position & Skills
  position: Position;
  preferredFoot: PreferredFoot;
  skills: PlayerSkill[];

  // Coach Notes
  strengths?: string;
  improvements?: string;
  generalNotes?: string;
}

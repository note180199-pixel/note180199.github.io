import { User, UserRole } from '@/types';

const USERS: User[] = [
  {
    username: 'adminpayukbaramee',
    password: '12345',
    role: 'admin',
    name: 'ผู้จัดการทีม',
    phone: '0812345678'
  },
  {
    username: 'coachpayukbaramee',
    password: '12345',
    role: 'coach',
    name: 'โค้ช',
    phone: '0823456789'
  },
  {
    username: 'payukbaramee',
    password: '12345',
    role: 'player',
    name: 'ผู้เล่น'
  }
];

export const login = (username: string, password: string): User | null => {
  const user = USERS.find(
    u => u.username.toLowerCase() === username.toLowerCase() && u.password === password
  );
  
  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
    return user;
  }
  
  return null;
};

export const logout = () => {
  localStorage.removeItem('currentUser');
};

export const getCurrentUser = (): User | null => {
  const userStr = localStorage.getItem('currentUser');
  return userStr ? JSON.parse(userStr) : null;
};

export const hasPermission = (role: UserRole, action: 'view' | 'edit' | 'editTeam'): boolean => {
  if (action === 'view') return true;
  if (action === 'editTeam') return role === 'admin';
  if (action === 'edit') return role === 'admin' || role === 'coach';
  return false;
};

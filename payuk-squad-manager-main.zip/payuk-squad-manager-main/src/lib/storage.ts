import { Team, Player } from '@/types';

const TEAM_KEY = 'footballTeam';
const PLAYERS_KEY = 'footballPlayers';

export const getTeam = (): Team => {
  const teamStr = localStorage.getItem(TEAM_KEY);
  if (teamStr) {
    return JSON.parse(teamStr);
  }
  
  // Default team
  const defaultTeam: Team = {
    id: '1',
    name: 'PAYUK BARAMEE FC',
    coaches: [],
    managers: []
  };
  
  saveTeam(defaultTeam);
  return defaultTeam;
};

export const saveTeam = (team: Team) => {
  localStorage.setItem(TEAM_KEY, JSON.stringify(team));
};

export const getPlayers = (): Player[] => {
  const playersStr = localStorage.getItem(PLAYERS_KEY);
  return playersStr ? JSON.parse(playersStr) : [];
};

export const savePlayers = (players: Player[]) => {
  localStorage.setItem(PLAYERS_KEY, JSON.stringify(players));
};

export const addPlayer = (player: Player) => {
  const players = getPlayers();
  players.push(player);
  savePlayers(players);
};

export const updatePlayer = (playerId: string, updatedPlayer: Player) => {
  const players = getPlayers();
  const index = players.findIndex(p => p.id === playerId);
  if (index !== -1) {
    players[index] = updatedPlayer;
    savePlayers(players);
  }
};

export const deletePlayer = (playerId: string) => {
  const players = getPlayers();
  savePlayers(players.filter(p => p.id !== playerId));
};

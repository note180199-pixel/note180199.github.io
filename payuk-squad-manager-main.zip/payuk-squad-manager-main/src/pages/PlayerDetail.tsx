import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { getCurrentUser, hasPermission } from '@/lib/auth';
import { getPlayers } from '@/lib/storage';
import { Player, Position } from '@/types';
import { ArrowLeft, Edit, User, Phone, Activity, FileText } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const PlayerDetail = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const user = getCurrentUser();
  const [player, setPlayer] = useState<Player | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }

    if (id) {
      const players = getPlayers();
      const found = players.find(p => p.id === id);
      if (found) {
        setPlayer(found);
      } else {
        navigate('/players');
      }
    }
  }, [id, user, navigate]);

  if (!player) return null;

  const positionLabels: Record<Position, string> = {
    'GK': 'ผู้รักษาประตู',
    'CB': 'กองหลังตัวกลาง',
    'LB': 'กองหลังซ้าย',
    'RB': 'กองหลังขวา',
    'CDM': 'กองกลางรับ',
    'CM': 'กองกลาง',
    'CAM': 'กองกลางรุก',
    'LW': 'ปีกซ้าย',
    'RW': 'ปีกขวา',
    'ST': 'กองหน้า'
  };

  const calculateAge = (birthDate: string) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="outline" onClick={() => navigate('/players')} className="gap-2">
            <ArrowLeft className="w-4 h-4" />
            กลับ
          </Button>
          {hasPermission(user!.role, 'edit') && (
            <Button onClick={() => navigate(`/players/edit/${id}`)} className="gap-2">
              <Edit className="w-4 h-4" />
              แก้ไข
            </Button>
          )}
        </div>

        {/* Profile Header */}
        <Card className="shadow-lg">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex-shrink-0">
                {player.profileImage ? (
                  <img src={player.profileImage} alt="Profile" className="w-32 h-32 rounded-full object-cover border-4 border-primary shadow-xl" />
                ) : (
                  <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-xl">
                    <User className="w-16 h-16 text-white" />
                  </div>
                )}
              </div>

              <div className="flex-1">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h1 className="text-4xl font-bold">{player.firstName} {player.lastName}</h1>
                    <p className="text-muted-foreground mt-1">รหัสนักเตะ: {player.playerId}</p>
                  </div>
                  <div className="text-center">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-3xl shadow-lg">
                      {player.jerseyNumber}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">เบอร์เสื้อ</p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-primary text-white px-3 py-1 text-sm">
                    {positionLabels[player.position]}
                  </Badge>
                  <Badge className="bg-accent text-white px-3 py-1 text-sm">
                    {player.ageGroup}
                  </Badge>
                  <Badge className="bg-secondary text-foreground px-3 py-1 text-sm">
                    เท้าถนัด: {player.preferredFoot}
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Basic Info */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5 text-primary" />
                ข้อมูลพื้นฐาน
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-sm text-muted-foreground">วันเกิด:</span>
                  <p className="font-medium">{new Date(player.birthDate).toLocaleDateString('th-TH')}</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">อายุ:</span>
                  <p className="font-medium">{calculateAge(player.birthDate)} ปี</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">ส่วนสูง:</span>
                  <p className="font-medium">{player.height} ซม.</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">น้ำหนัก:</span>
                  <p className="font-medium">{player.weight} กก.</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">กรุ๊ปเลือด:</span>
                  <p className="font-medium">{player.bloodType}</p>
                </div>
                <div>
                  <span className="text-sm text-muted-foreground">รุ่น:</span>
                  <p className="font-medium">{player.ageGroup}</p>
                </div>
              </div>
              {player.healthNotes && (
                <div className="pt-3 border-t">
                  <span className="text-sm text-muted-foreground">หมายเหตุสุขภาพ:</span>
                  <p className="mt-1 text-sm bg-muted/30 p-2 rounded">{player.healthNotes}</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="w-5 h-5 text-primary" />
                ข้อมูลการติดต่อ
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <span className="text-sm text-muted-foreground">ชื่อผู้ปกครอง:</span>
                <p className="font-medium">{player.parentName}</p>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">เบอร์ผู้ปกครอง:</span>
                <p className="font-medium">{player.parentPhone}</p>
              </div>
              {player.playerPhone && (
                <div>
                  <span className="text-sm text-muted-foreground">เบอร์นักเตะ:</span>
                  <p className="font-medium">{player.playerPhone}</p>
                </div>
              )}
              {player.facebook && (
                <div>
                  <span className="text-sm text-muted-foreground">Facebook:</span>
                  <p className="font-medium">{player.facebook}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Skills */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              ทักษะ
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {player.skills.map((skill, index) => (
                <div key={index} className="p-4 bg-muted/30 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">{skill.name}</span>
                    <span className="text-2xl font-bold text-primary">{skill.score}/10</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-primary to-accent h-2 rounded-full transition-all"
                      style={{ width: `${(skill.score / 10) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Coach Notes */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              หมายเหตุโค้ช
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {player.strengths && (
              <div>
                <h3 className="font-medium mb-2 text-green-600">จุดเด่น</h3>
                <p className="text-sm bg-green-50 p-3 rounded">{player.strengths}</p>
              </div>
            )}
            {player.improvements && (
              <div>
                <h3 className="font-medium mb-2 text-orange-600">สิ่งที่ควรพัฒนา</h3>
                <p className="text-sm bg-orange-50 p-3 rounded">{player.improvements}</p>
              </div>
            )}
            {player.generalNotes && (
              <div>
                <h3 className="font-medium mb-2">หมายเหตุทั่วไป</h3>
                <p className="text-sm bg-muted/30 p-3 rounded">{player.generalNotes}</p>
              </div>
            )}
            {!player.strengths && !player.improvements && !player.generalNotes && (
              <p className="text-center text-muted-foreground py-4">ยังไม่มีหมายเหตุจากโค้ช</p>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default PlayerDetail;

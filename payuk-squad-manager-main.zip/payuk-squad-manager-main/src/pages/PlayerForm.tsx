import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { getCurrentUser, hasPermission } from '@/lib/auth';
import { getPlayers, addPlayer, updatePlayer } from '@/lib/storage';
import { Player, Position, AgeGroup, PreferredFoot, BloodType, PlayerSkill } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { Save, UserPlus, Trash2 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const PlayerForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const user = getCurrentUser();
  const { toast } = useToast();
  const isEdit = Boolean(id);

  const defaultSkills: PlayerSkill[] = [
    { name: 'ความเร็ว', score: 5 },
    { name: 'ความแข็งแรง', score: 5 },
    { name: 'การเลี้ยงบอล', score: 5 },
    { name: 'การส่งบอล', score: 5 },
    { name: 'การยิงประตู', score: 5 },
    { name: 'การป้องกัน', score: 5 },
  ];

  const [formData, setFormData] = useState<Player>({
    id: '',
    profileImage: '',
    playerId: '',
    jerseyNumber: 0,
    firstName: '',
    lastName: '',
    birthDate: '',
    ageGroup: 'U10',
    height: 0,
    weight: 0,
    bloodType: 'O',
    healthNotes: '',
    parentName: '',
    parentPhone: '',
    playerPhone: '',
    facebook: '',
    position: 'ST',
    preferredFoot: 'ขวา',
    skills: defaultSkills,
    strengths: '',
    improvements: '',
    generalNotes: '',
  });

  useEffect(() => {
    if (!user || !hasPermission(user.role, 'edit')) {
      toast({
        title: 'ไม่มีสิทธิ์',
        description: 'คุณไม่มีสิทธิ์เพิ่มหรือแก้ไขนักเตะ',
        variant: 'destructive',
      });
      navigate('/players');
      return;
    }

    if (isEdit && id) {
      const players = getPlayers();
      const player = players.find(p => p.id === id);
      if (player) {
        setFormData(player);
      } else {
        toast({
          title: 'ไม่พบข้อมูล',
          description: 'ไม่พบนักเตะที่ต้องการแก้ไข',
          variant: 'destructive',
        });
        navigate('/players');
      }
    }
  }, [id, isEdit, user, navigate, toast]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, profileImage: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const updateSkill = (index: number, score: number) => {
    const newSkills = [...formData.skills];
    newSkills[index].score = score;
    setFormData({ ...formData, skills: newSkills });
  };

  const addCustomSkill = () => {
    setFormData({
      ...formData,
      skills: [...formData.skills, { name: '', score: 5 }]
    });
  };

  const updateCustomSkillName = (index: number, name: string) => {
    const newSkills = [...formData.skills];
    newSkills[index].name = name;
    setFormData({ ...formData, skills: newSkills });
  };

  const removeCustomSkill = (index: number) => {
    setFormData({
      ...formData,
      skills: formData.skills.filter((_, i) => i !== index)
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (isEdit && id) {
      updatePlayer(id, formData);
      toast({
        title: 'บันทึกสำเร็จ',
        description: 'แก้ไขข้อมูลนักเตะเรียบร้อยแล้ว',
      });
    } else {
      addPlayer({ ...formData, id: Date.now().toString() });
      toast({
        title: 'เพิ่มสำเร็จ',
        description: 'เพิ่มนักเตะใหม่เรียบร้อยแล้ว',
      });
    }

    navigate('/players');
  };

  return (
    <Layout>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-4xl font-bold text-foreground">
            {isEdit ? 'แก้ไขนักเตะ' : 'เพิ่มนักเตะ'}
          </h1>
          <Button type="submit" size="lg" className="gap-2 shadow-lg">
            <Save className="w-5 h-5" />
            บันทึก
          </Button>
        </div>

        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="basic">ข้อมูลพื้นฐาน</TabsTrigger>
            <TabsTrigger value="contact">การติดต่อ</TabsTrigger>
            <TabsTrigger value="skills">ตำแหน่ง & ทักษะ</TabsTrigger>
            <TabsTrigger value="notes">หมายเหตุโค้ช</TabsTrigger>
          </TabsList>

          <TabsContent value="basic">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>ข้อมูลพื้นฐาน</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium">รูปโปรไฟล์</label>
                  <div className="flex items-center gap-4 mt-2">
                    {formData.profileImage && (
                      <img src={formData.profileImage} alt="Profile" className="w-24 h-24 rounded-full object-cover border-4 border-primary shadow-md" />
                    )}
                    <Input
                      type="file"
                      accept=".png,.jpg,.jpeg"
                      onChange={handleImageUpload}
                      className="max-w-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">รหัสนักเตะ *</label>
                    <Input
                      value={formData.playerId}
                      onChange={(e) => setFormData({ ...formData, playerId: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">เลขเสื้อ *</label>
                    <Input
                      type="number"
                      value={formData.jerseyNumber || ''}
                      onChange={(e) => setFormData({ ...formData, jerseyNumber: parseInt(e.target.value) || 0 })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">ชื่อ *</label>
                    <Input
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">นามสกุล *</label>
                    <Input
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">วันเกิด *</label>
                    <Input
                      type="date"
                      value={formData.birthDate}
                      onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">รุ่น *</label>
                    <Select value={formData.ageGroup} onValueChange={(value) => setFormData({ ...formData, ageGroup: value as AgeGroup })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="U10">U10</SelectItem>
                        <SelectItem value="U12">U12</SelectItem>
                        <SelectItem value="U14">U14</SelectItem>
                        <SelectItem value="U16">U16</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium">ส่วนสูง (ซม.) *</label>
                    <Input
                      type="number"
                      value={formData.height || ''}
                      onChange={(e) => setFormData({ ...formData, height: parseInt(e.target.value) || 0 })}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">น้ำหนัก (กก.) *</label>
                    <Input
                      type="number"
                      value={formData.weight || ''}
                      onChange={(e) => setFormData({ ...formData, weight: parseInt(e.target.value) || 0 })}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">กรุ๊ปเลือด *</label>
                    <Select value={formData.bloodType} onValueChange={(value) => setFormData({ ...formData, bloodType: value as BloodType })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {['A', 'B', 'AB', 'O', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(type => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium">หมายเหตุสุขภาพ</label>
                  <Textarea
                    value={formData.healthNotes}
                    onChange={(e) => setFormData({ ...formData, healthNotes: e.target.value })}
                    placeholder="ระบุข้อมูลสุขภาพที่สำคัญ เช่น โรคประจำตัว แพ้ยา"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contact">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>การติดต่อ</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">ชื่อผู้ปกครอง *</label>
                    <Input
                      value={formData.parentName}
                      onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">เบอร์ผู้ปกครอง *</label>
                    <Input
                      value={formData.parentPhone}
                      onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">เบอร์นักเตะ</label>
                    <Input
                      value={formData.playerPhone}
                      onChange={(e) => setFormData({ ...formData, playerPhone: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Facebook นักเตะ</label>
                    <Input
                      value={formData.facebook}
                      onChange={(e) => setFormData({ ...formData, facebook: e.target.value })}
                      placeholder="ชื่อ Facebook หรือ URL"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="skills">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>ตำแหน่งและทักษะ</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">ตำแหน่งหลัก *</label>
                    <Select value={formData.position} onValueChange={(value) => setFormData({ ...formData, position: value as Position })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="GK">GK - ผู้รักษาประตู</SelectItem>
                        <SelectItem value="CB">CB - กองหลังตัวกลาง</SelectItem>
                        <SelectItem value="LB">LB - กองหลังซ้าย</SelectItem>
                        <SelectItem value="RB">RB - กองหลังขวา</SelectItem>
                        <SelectItem value="CDM">CDM - กองกลางรับ</SelectItem>
                        <SelectItem value="CM">CM - กองกลาง</SelectItem>
                        <SelectItem value="CAM">CAM - กองกลางรุก</SelectItem>
                        <SelectItem value="LW">LW - ปีกซ้าย</SelectItem>
                        <SelectItem value="RW">RW - ปีกขวา</SelectItem>
                        <SelectItem value="ST">ST - กองหน้า</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">ถนัดเท้า *</label>
                    <Select value={formData.preferredFoot} onValueChange={(value) => setFormData({ ...formData, preferredFoot: value as PreferredFoot })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ซ้าย">ซ้าย</SelectItem>
                        <SelectItem value="ขวา">ขวา</SelectItem>
                        <SelectItem value="ทั้งสอง">ทั้งสองเท้า</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium">ทักษะ (คะแนน 1-10)</h3>
                    <Button type="button" onClick={addCustomSkill} size="sm" variant="outline">
                      <UserPlus className="w-4 h-4 mr-2" />
                      เพิ่มทักษะ
                    </Button>
                  </div>

                  {formData.skills.map((skill, index) => (
                    <div key={index} className="space-y-2 p-4 bg-muted/30 rounded-lg">
                      <div className="flex items-center gap-2">
                        {index >= 6 ? (
                          <Input
                            value={skill.name}
                            onChange={(e) => updateCustomSkillName(index, e.target.value)}
                            placeholder="ชื่อทักษะ"
                            className="flex-1"
                          />
                        ) : (
                          <label className="flex-1 font-medium">{skill.name}</label>
                        )}
                        <span className="text-2xl font-bold text-primary w-12 text-center">{skill.score}</span>
                        {index >= 6 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => removeCustomSkill(index)}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        )}
                      </div>
                      <Slider
                        value={[skill.score]}
                        onValueChange={(value) => updateSkill(index, value[0])}
                        min={1}
                        max={10}
                        step={1}
                        className="w-full"
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notes">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>หมายเหตุโค้ช</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium">จุดเด่น</label>
                  <Textarea
                    value={formData.strengths}
                    onChange={(e) => setFormData({ ...formData, strengths: e.target.value })}
                    placeholder="ระบุจุดเด่นของนักเตะ"
                    rows={4}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">สิ่งที่ควรพัฒนา</label>
                  <Textarea
                    value={formData.improvements}
                    onChange={(e) => setFormData({ ...formData, improvements: e.target.value })}
                    placeholder="ระบุสิ่งที่ควรพัฒนา"
                    rows={4}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">หมายเหตุทั่วไป</label>
                  <Textarea
                    value={formData.generalNotes}
                    onChange={(e) => setFormData({ ...formData, generalNotes: e.target.value })}
                    placeholder="หมายเหตุอื่นๆ"
                    rows={4}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </form>
    </Layout>
  );
};

export default PlayerForm;

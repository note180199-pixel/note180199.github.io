import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getCurrentUser, hasPermission } from '@/lib/auth';
import { getPlayers, deletePlayer } from '@/lib/storage';
import { Player, Position, AgeGroup } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { Search, UserPlus, Eye, Edit, Trash2, Users } from 'lucide-react';

const Players = () => {
  const navigate = useNavigate();
  const user = getCurrentUser();
  const { toast } = useToast();
  const [players, setPlayers] = useState<Player[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPosition, setFilterPosition] = useState<string>('all');
  const [filterAgeGroup, setFilterAgeGroup] = useState<string>('all');

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    loadPlayers();
  }, [user, navigate]);

  const loadPlayers = () => {
    setPlayers(getPlayers());
  };

  const handleDelete = (id: string) => {
    if (!hasPermission(user!.role, 'edit')) {
      toast({
        title: 'ไม่มีสิทธิ์',
        description: 'คุณไม่มีสิทธิ์ลบนักเตะ',
        variant: 'destructive',
      });
      return;
    }

    if (confirm('คุณต้องการลบนักเตะคนนี้หรือไม่?')) {
      deletePlayer(id);
      loadPlayers();
      toast({
        title: 'ลบสำเร็จ',
        description: 'ลบนักเตะเรียบร้อยแล้ว',
      });
    }
  };

  const filteredPlayers = players.filter(player => {
    const matchSearch = 
      player.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      player.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      player.playerId.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchPosition = filterPosition === 'all' || player.position === filterPosition;
    const matchAgeGroup = filterAgeGroup === 'all' || player.ageGroup === filterAgeGroup;

    return matchSearch && matchPosition && matchAgeGroup;
  });

  const positionLabels: Record<Position, string> = {
    'GK': 'GK', 'CB': 'CB', 'LB': 'LB', 'RB': 'RB',
    'CDM': 'CDM', 'CM': 'CM', 'CAM': 'CAM',
    'LW': 'LW', 'RW': 'RW', 'ST': 'ST'
  };

  const calculateAge = (birthDate: string) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Users className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold text-foreground">รายชื่อนักเตะ</h1>
          </div>
          {hasPermission(user!.role, 'edit') && (
            <Button onClick={() => navigate('/players/add')} className="gap-2 shadow-lg">
              <UserPlus className="w-5 h-5" />
              เพิ่มนักเตะ
            </Button>
          )}
        </div>

        {/* Filters */}
        <Card className="shadow-md">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="ค้นหา ชื่อ, นามสกุล, รหัสนักเตะ..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={filterPosition} onValueChange={setFilterPosition}>
                <SelectTrigger>
                  <SelectValue placeholder="เลือกตำแหน่ง" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ทุกตำแหน่ง</SelectItem>
                  {Object.entries(positionLabels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filterAgeGroup} onValueChange={setFilterAgeGroup}>
                <SelectTrigger>
                  <SelectValue placeholder="เลือกรุ่น" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ทุกรุ่น</SelectItem>
                  <SelectItem value="U10">U10</SelectItem>
                  <SelectItem value="U12">U12</SelectItem>
                  <SelectItem value="U14">U14</SelectItem>
                  <SelectItem value="U16">U16</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Players Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlayers.map(player => (
            <Card key={player.id} className="shadow-lg hover:shadow-xl transition-shadow overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-2xl flex-shrink-0 shadow-md">
                    {player.jerseyNumber}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-lg truncate">{player.firstName} {player.lastName}</h3>
                    <p className="text-sm text-muted-foreground">รหัส: {player.playerId}</p>
                    <div className="flex gap-2 mt-2 flex-wrap">
                      <span className="px-2 py-1 bg-primary/10 text-primary rounded text-xs font-medium">
                        {positionLabels[player.position]}
                      </span>
                      <span className="px-2 py-1 bg-accent/10 text-accent rounded text-xs font-medium">
                        {player.ageGroup}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">อายุ:</span>
                    <span className="ml-1 font-medium">{calculateAge(player.birthDate)} ปี</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">ส่วนสูง:</span>
                    <span className="ml-1 font-medium">{player.height} ซม.</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">น้ำหนัก:</span>
                    <span className="ml-1 font-medium">{player.weight} กก.</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">เท้าถนัด:</span>
                    <span className="ml-1 font-medium">{player.preferredFoot}</span>
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate(`/players/${player.id}`)}
                    className="flex-1 gap-1"
                  >
                    <Eye className="w-4 h-4" />
                    ดูรายละเอียด
                  </Button>
                  
                  {hasPermission(user!.role, 'edit') && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navigate(`/players/edit/${player.id}`)}
                        className="gap-1"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDelete(player.id)}
                        className="gap-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredPlayers.length === 0 && (
          <Card className="shadow-md">
            <CardContent className="py-12 text-center">
              <Users className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <p className="text-lg text-muted-foreground">ไม่พบนักเตะที่ค้นหา</p>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
};

export default Players;

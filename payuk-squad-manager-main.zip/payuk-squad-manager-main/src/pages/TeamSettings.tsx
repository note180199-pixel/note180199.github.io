import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { getCurrentUser, hasPermission } from '@/lib/auth';
import { getTeam, saveTeam } from '@/lib/storage';
import { Team, Coach, Manager } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { Settings, Upload, UserPlus, Trash2 } from 'lucide-react';

const TeamSettings = () => {
  const navigate = useNavigate();
  const user = getCurrentUser();
  const { toast } = useToast();
  const [team, setTeam] = useState<Team>(getTeam());

  useEffect(() => {
    if (!user || !hasPermission(user.role, 'editTeam')) {
      toast({
        title: 'ไม่มีสิทธิ์เข้าถึง',
        description: 'เฉพาะผู้จัดการทีมเท่านั้นที่สามารถแก้ไขการตั้งค่าทีม',
        variant: 'destructive',
      });
      navigate('/dashboard');
    }
  }, [user, navigate, toast]);

  const handleSave = () => {
    saveTeam(team);
    toast({
      title: 'บันทึกสำเร็จ',
      description: 'ข้อมูลทีมได้รับการอัพเดทแล้ว',
    });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTeam({ ...team, logo: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const addCoach = () => {
    const newCoach: Coach = {
      id: Date.now().toString(),
      name: '',
      phone: ''
    };
    setTeam({ ...team, coaches: [...team.coaches, newCoach] });
  };

  const updateCoach = (id: string, field: keyof Coach, value: string) => {
    setTeam({
      ...team,
      coaches: team.coaches.map(c => c.id === id ? { ...c, [field]: value } : c)
    });
  };

  const removeCoach = (id: string) => {
    setTeam({
      ...team,
      coaches: team.coaches.filter(c => c.id !== id)
    });
  };

  const addManager = () => {
    const newManager: Manager = {
      id: Date.now().toString(),
      name: '',
      phone: ''
    };
    setTeam({ ...team, managers: [...team.managers, newManager] });
  };

  const updateManager = (id: string, field: keyof Manager, value: string) => {
    setTeam({
      ...team,
      managers: team.managers.map(m => m.id === id ? { ...m, [field]: value } : m)
    });
  };

  const removeManager = (id: string) => {
    setTeam({
      ...team,
      managers: team.managers.filter(m => m.id !== id)
    });
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex items-center gap-3">
          <Settings className="w-8 h-8 text-primary" />
          <h1 className="text-4xl font-bold text-foreground">ตั้งค่าทีม</h1>
        </div>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>ข้อมูลทีม</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium">โลโก้ทีม</label>
              <div className="flex items-center gap-4">
                {team.logo && (
                  <img src={team.logo} alt="Team Logo" className="w-24 h-24 rounded-full object-cover border-4 border-primary shadow-md" />
                )}
                <div>
                  <Input
                    type="file"
                    accept=".png,.jpg,.jpeg"
                    onChange={handleImageUpload}
                    className="max-w-xs"
                  />
                  <p className="text-xs text-muted-foreground mt-1">รองรับไฟล์ PNG, JPG</p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">ชื่อทีม</label>
              <Input
                value={team.name}
                onChange={(e) => setTeam({ ...team, name: e.target.value })}
                placeholder="ชื่อทีม"
                className="max-w-md"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>โค้ช</CardTitle>
              <Button onClick={addCoach} size="sm" className="gap-2">
                <UserPlus className="w-4 h-4" />
                เพิ่มโค้ช
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {team.coaches.map((coach) => (
              <div key={coach.id} className="flex gap-4 p-4 bg-muted/30 rounded-lg">
                <Input
                  placeholder="ชื่อโค้ช"
                  value={coach.name}
                  onChange={(e) => updateCoach(coach.id, 'name', e.target.value)}
                />
                <Input
                  placeholder="เบอร์โทร"
                  value={coach.phone}
                  onChange={(e) => updateCoach(coach.id, 'phone', e.target.value)}
                />
                <Button
                  variant="destructive"
                  size="icon"
                  onClick={() => removeCoach(coach.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
            {team.coaches.length === 0 && (
              <p className="text-center text-muted-foreground py-4">ยังไม่มีโค้ช</p>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>ผู้จัดการทีม</CardTitle>
              <Button onClick={addManager} size="sm" className="gap-2">
                <UserPlus className="w-4 h-4" />
                เพิ่มผู้จัดการ
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {team.managers.map((manager) => (
              <div key={manager.id} className="flex gap-4 p-4 bg-muted/30 rounded-lg">
                <Input
                  placeholder="ชื่อผู้จัดการ"
                  value={manager.name}
                  onChange={(e) => updateManager(manager.id, 'name', e.target.value)}
                />
                <Input
                  placeholder="เบอร์โทร"
                  value={manager.phone}
                  onChange={(e) => updateManager(manager.id, 'phone', e.target.value)}
                />
                <Button
                  variant="destructive"
                  size="icon"
                  onClick={() => removeManager(manager.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
            {team.managers.length === 0 && (
              <p className="text-center text-muted-foreground py-4">ยังไม่มีผู้จัดการทีม</p>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button onClick={handleSave} size="lg" className="gap-2 shadow-lg">
            <Upload className="w-5 h-5" />
            บันทึกการเปลี่ยนแปลง
          </Button>
        </div>
      </div>
    </Layout>
  );
};

export default TeamSettings;

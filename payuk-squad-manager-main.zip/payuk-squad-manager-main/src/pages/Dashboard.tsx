import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { getCurrentUser } from '@/lib/auth';
import { getPlayers, getTeam } from '@/lib/storage';
import { Users, Target, Calendar, TrendingUp } from 'lucide-react';
import { Position, AgeGroup } from '@/types';

const Dashboard = () => {
  const navigate = useNavigate();
  const user = getCurrentUser();
  const [stats, setStats] = useState({
    totalPlayers: 0,
    byPosition: {} as Record<Position, number>,
    byAgeGroup: {} as Record<AgeGroup, number>
  });

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }

    const players = getPlayers();
    const team = getTeam();

    // Calculate stats
    const byPosition: Record<string, number> = {};
    const byAgeGroup: Record<string, number> = {};

    players.forEach(player => {
      byPosition[player.position] = (byPosition[player.position] || 0) + 1;
      byAgeGroup[player.ageGroup] = (byAgeGroup[player.ageGroup] || 0) + 1;
    });

    setStats({
      totalPlayers: players.length,
      byPosition,
      byAgeGroup
    });
  }, [user, navigate]);

  const positionLabels: Record<Position, string> = {
    'GK': 'ผู้รักษาประตู',
    'CB': 'กองหลังตัวกลาง',
    'LB': 'กองหลังซ้าย',
    'RB': 'กองหลังขวา',
    'CDM': 'กองกลางรับ',
    'CM': 'กองกลาง',
    'CAM': 'กองกลางรุก',
    'LW': 'ปีกซ้าย',
    'RW': 'ปีกขวา',
    'ST': 'กองหน้า'
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground">Dashboard</h1>
            <p className="text-muted-foreground mt-2">ภาพรวมทีม PAYUK BARAMEE FC</p>
          </div>
          <div className="h-16 w-16 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center shadow-xl">
            <Users className="w-8 h-8 text-white" />
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-l-4 border-l-primary shadow-md hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">จำนวนนักเตะทั้งหมด</CardTitle>
              <Users className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-primary">{stats.totalPlayers}</div>
              <p className="text-xs text-muted-foreground mt-1">คน</p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-accent shadow-md hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">จำนวนตำแหน่ง</CardTitle>
              <Target className="h-5 w-5 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-accent">{Object.keys(stats.byPosition).length}</div>
              <p className="text-xs text-muted-foreground mt-1">ตำแหน่ง</p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-secondary shadow-md hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">จำนวนรุ่น</CardTitle>
              <Calendar className="h-5 w-5 text-secondary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-secondary">{Object.keys(stats.byAgeGroup).length}</div>
              <p className="text-xs text-muted-foreground mt-1">รุ่นอายุ</p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-primary shadow-md hover:shadow-xl transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ทีมที่ใหญ่ที่สุด</CardTitle>
              <TrendingUp className="h-5 w-5 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">
                {Object.entries(stats.byAgeGroup).sort((a, b) => b[1] - a[1])[0]?.[0] || '-'}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {Object.entries(stats.byAgeGroup).sort((a, b) => b[1] - a[1])[0]?.[1] || 0} คน
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                จำนวนนักเตะแต่ละตำแหน่ง
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(stats.byPosition).map(([position, count]) => (
                  <div key={position} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                    <span className="font-medium">{positionLabels[position as Position]}</span>
                    <span className="text-xl font-bold text-primary">{count}</span>
                  </div>
                ))}
                {Object.keys(stats.byPosition).length === 0 && (
                  <p className="text-center text-muted-foreground py-8">ยังไม่มีข้อมูลนักเตะ</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-accent" />
                จำนวนนักเตะแต่ละรุ่น
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {(['U10', 'U12', 'U14', 'U16'] as AgeGroup[]).map(ageGroup => (
                  <div key={ageGroup} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                    <span className="font-medium">{ageGroup}</span>
                    <span className="text-xl font-bold text-accent">{stats.byAgeGroup[ageGroup] || 0}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;

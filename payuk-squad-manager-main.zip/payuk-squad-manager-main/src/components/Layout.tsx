import { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { getCurrentUser, logout } from '@/lib/auth';
import { LogOut, Users, Settings, Home } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const navigate = useNavigate();
  const user = getCurrentUser();
  const { toast } = useToast();

  const handleLogout = () => {
    logout();
    toast({
      title: 'ออกจากระบบสำเร็จ',
      description: 'ขอบคุณที่ใช้งาน',
    });
    navigate('/');
  };

  const roleName = {
    admin: 'ผู้จัดการทีม',
    coach: 'โค้ช',
    player: 'ผู้เล่น'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
      <nav className="bg-white border-b-4 border-primary shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  ระบบจัดการทีมฟุตบอล
                </h1>
                {user && (
                  <p className="text-xs text-muted-foreground">
                    {user.name} ({roleName[user.role]})
                  </p>
                )}
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/dashboard')}
                className="gap-2"
              >
                <Home className="w-4 h-4" />
                หน้าหลัก
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/players')}
                className="gap-2"
              >
                <Users className="w-4 h-4" />
                นักเตะ
              </Button>
              
              {user?.role === 'admin' && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate('/team-settings')}
                  className="gap-2"
                >
                  <Settings className="w-4 h-4" />
                  ตั้งค่า
                </Button>
              )}
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="gap-2 border-primary text-primary hover:bg-primary hover:text-white"
              >
                <LogOut className="w-4 h-4" />
                ออกจากระบบ
              </Button>
            </div>
          </div>
        </div>
      </nav>
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
};

export default Layout;
